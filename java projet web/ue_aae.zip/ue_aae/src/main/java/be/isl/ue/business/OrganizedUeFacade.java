/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package be.isl.ue.business;

import be.isl.ue.entity.OrganizedUe;
import be.isl.ue.entity.Section;
import be.isl.ue.viewmodel.OrganizedUeSearchVM;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author ahmad
 */
@Stateless
public class OrganizedUeFacade extends AbstractFacade<OrganizedUe, OrganizedUeSearchVM> {

    @PersistenceContext(unitName = "UePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public OrganizedUeFacade() {
        super(OrganizedUe.class);
    }

    @Override
    public List<OrganizedUe> findVM(OrganizedUeSearchVM s) {
        List<OrganizedUe> resultat;
        String jpql= "select s from organized_ue s " ;  
        Query q=em.createQuery(jpql);
        resultat =(List<OrganizedUe> )q.getResultList();
                return resultat ;
    }
    
}
