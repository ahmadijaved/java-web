package be.isl.ue.entity;

public abstract class AbstractEntity 
{
    public abstract Integer getId();
}
